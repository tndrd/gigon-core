#define MAC 1
#define MACX 1
#define WINDOWS 0
#define SGI 0
#define MOTIF 0
#define BEBOX 0

#define USE_NAMESPACE 0

#define TARGET_API_MAC_CARBON 1
#define USENAVSERVICES 1

#define __CF_USE_FRAMEWORK_INCLUDES__

#if __MWERKS__
#define __NOEXTENSIONS__
#endif

#define QUARTZ 1

#define MAC_OS_X_VERSION_MIN_REQUIRED   1020
#define MAC_OS_X_VERSION_MAX_ALLOWED	1030

#include <AvailabilityMacros.h>
